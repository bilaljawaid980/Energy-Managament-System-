public class Admin {
    private String username;
    private String password;
  

    public Admin() {
        this.username = "admin";
        this.password = "123";
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

//    public void setAppliances() {
//        // Implement the logic to set appliances for admin
//    	Appliance a1=new Appliance("Light",10.23);
//    	applist.add(a1);
//    	Appliance a2=new Appliance("Bulb",9.23);
//    	applist.add(a2);
//    	Appliance a3=new Appliance("TV",11.23);
//    	applist.add(a3);
//    	Appliance a4=new Appliance("Refridgerator",15.23);
//    	applist.add(a4);
//    	Appliance a5=new Appliance("Fan",16.23);
//    	applist.add(a5);
//    }
}
